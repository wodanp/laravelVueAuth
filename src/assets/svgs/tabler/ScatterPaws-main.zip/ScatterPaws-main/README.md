# ScatterPaws

## Disclaimer

My Twitch chat is allowed to redeem channel points to customize my commit messages. This can sometimes appear a bit sussy. When encountering a sussy commit, I guarentee 100% of the time, reading through the changes will dispell all concerns.

## Play

[https://evannorton.github.io/ScatterPaws/out/index.html](https://evannorton.github.io/ScatterPaws/out/index.html)

## Credits
EvanMMO - Programming

Riazey - Graphics

Osyris - Graphics

Ragchomp - Audio
