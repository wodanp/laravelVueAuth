interface Coords {
  readonly x: number;
  readonly y: number;
}

export default Coords;