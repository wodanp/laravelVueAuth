interface FadeOutAction {
  readonly duration: number;
  readonly startedAt: number | null;
}

export default FadeOutAction;