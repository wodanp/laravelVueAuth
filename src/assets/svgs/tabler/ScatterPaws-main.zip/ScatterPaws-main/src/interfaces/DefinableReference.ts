interface DefinableReference {
  readonly className: string;
  readonly slug: string;
}

export default DefinableReference;