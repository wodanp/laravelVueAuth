interface RGB {
  b: number;
  g: number;
  r: number;
}

export default RGB;