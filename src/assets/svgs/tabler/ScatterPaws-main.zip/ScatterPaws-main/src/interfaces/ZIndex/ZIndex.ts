import ZIndexType from "../../enums/ZIndexType";

interface ZIndex {
  readonly type: ZIndexType;
}

export default ZIndex;