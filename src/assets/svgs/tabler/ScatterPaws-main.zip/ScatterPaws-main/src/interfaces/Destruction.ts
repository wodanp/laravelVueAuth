interface Destruction {
  readonly clawedAt: number;
  readonly destructibleID: string | null;
  readonly tileID: number | null;
}

export default Destruction;