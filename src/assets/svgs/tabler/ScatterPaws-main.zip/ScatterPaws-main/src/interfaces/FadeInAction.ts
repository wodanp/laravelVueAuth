interface FadeInAction {
  readonly duration: number;
  readonly startedAt: number | null;
}

export default FadeInAction;