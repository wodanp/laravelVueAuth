interface Credit {
  readonly link: string;
  readonly x: number;
  readonly y: number;
  readonly width: number;
  readonly height: number;
}

export default Credit;