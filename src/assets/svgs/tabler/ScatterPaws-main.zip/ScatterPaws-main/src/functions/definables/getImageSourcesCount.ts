import getDefinablesCount from "./getDefinablesCount";

const getImageSourcesCount = (): number => getDefinablesCount("ImageSource");

export default getImageSourcesCount;