import State from "./classes/State";

const state: State = new State;

export default state;