enum ZIndexType {
  Hard = "hard",
  YSort = "y-sort"
}

export default ZIndexType;