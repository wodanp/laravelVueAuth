enum CollisionType {
  Bonk = "bonk",
  Obstacle = "obstacle"
}

export default CollisionType;