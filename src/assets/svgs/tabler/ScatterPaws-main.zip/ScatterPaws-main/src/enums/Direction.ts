enum Direction {
  DownLeft = "down-left",
  DownRight = "down-right",
  UpLeft = "up-left",
  UpRight = "up-right"
}

export default Direction;