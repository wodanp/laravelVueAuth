const timePerIndicatorFrame: number = 200;

export default timePerIndicatorFrame;