const obstacleDuration: number = 2500;

export default obstacleDuration;