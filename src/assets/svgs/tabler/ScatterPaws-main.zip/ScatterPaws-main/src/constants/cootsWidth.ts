const cootsWidth: number = 21;

export default cootsWidth;