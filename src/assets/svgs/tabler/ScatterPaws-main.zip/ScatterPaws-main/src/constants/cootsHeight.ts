const cootsHeight: number = 19;

export default cootsHeight;