const gameHeight: number = 180;

export default gameHeight;