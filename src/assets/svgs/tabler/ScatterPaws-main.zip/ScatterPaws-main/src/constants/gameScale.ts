const gameScale: number = 4;

export default gameScale;