const gameWidth: number = 320;

export default gameWidth;