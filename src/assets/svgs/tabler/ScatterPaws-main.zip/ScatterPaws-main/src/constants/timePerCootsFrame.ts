const timePerCootsFrame = 100;

export default timePerCootsFrame;