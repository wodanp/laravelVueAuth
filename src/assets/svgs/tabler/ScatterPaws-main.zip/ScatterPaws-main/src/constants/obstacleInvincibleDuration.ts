const obstacleInvincibleDuration: number = 1000;

export default obstacleInvincibleDuration;