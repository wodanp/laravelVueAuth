const unitsPerTile: number = 10000;

export default unitsPerTile;