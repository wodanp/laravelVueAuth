const ludwigTheming: boolean = true;

export default ludwigTheming;