const runningThreshold: number = .9;

export default runningThreshold;