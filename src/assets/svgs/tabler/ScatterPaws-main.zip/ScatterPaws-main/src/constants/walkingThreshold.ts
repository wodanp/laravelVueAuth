const walkingThreshold: number = .15;

export default walkingThreshold;