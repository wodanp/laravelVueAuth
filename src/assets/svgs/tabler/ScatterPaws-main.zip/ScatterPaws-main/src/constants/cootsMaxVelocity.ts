import unitsPerTile from "./unitsPerTile";

const cootsMaxVelocity: number = unitsPerTile * 16;

export default cootsMaxVelocity;